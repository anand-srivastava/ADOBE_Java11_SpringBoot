package client;

import java.util.ServiceLoader;

import com.example.log.LogService;

public class Client {
	public static void main(String[] args) {
		ServiceLoader<LogService> loader = ServiceLoader.load(LogService.class);
		System.out.println(loader.findFirst());
		for (LogService service : loader) {
			service.log("Log written by " + service.getClass());
		}
	}
}
