package com.adobe.empservice;

import java.util.logging.*;

import com.adobe.util.DbUtil;

public class EmployeeService {
        private static Logger LOGGER = Logger.getLogger(EmployeeService.class.getName());

        public void addEmployee(String name , String email) {
            LOGGER.log(Level.INFO, "Added " + name + "," + email);
            DbUtil.util();
        }
}