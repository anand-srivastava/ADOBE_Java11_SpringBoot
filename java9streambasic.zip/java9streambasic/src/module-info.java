module java9streambasic {
	requires java.logging;
}