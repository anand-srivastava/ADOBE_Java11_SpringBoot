javac --module-source-path src -m com.adobe.service,client.module -d out

java --module-path out -m client.module/client.Main

