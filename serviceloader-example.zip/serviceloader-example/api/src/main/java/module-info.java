module log.api {
    exports com.example.log;
}