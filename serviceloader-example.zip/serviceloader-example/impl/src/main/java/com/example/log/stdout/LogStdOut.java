package com.example.log.stdout;

import com.example.log.LogService;

public class LogStdOut implements LogService {

	@Override
	public void log(String message) {
		System.out.println(message);
	}

}
