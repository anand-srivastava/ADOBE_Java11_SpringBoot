package java9streamsimple;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.SubmissionPublisher;

public class ReactiveApp {
	public static List<Employee> getEmps() {

		Employee e1 = new Employee(1, "Banu");
		Employee e2 = new Employee(2, "Rahul");
		Employee e3 = new Employee(3, "Smitha");
		Employee e4 = new Employee(4, "Ramesh");
		Employee e5 = new Employee(5, "Anupama");

		List<Employee> emps = new ArrayList<>();
		emps.add(e1);
		emps.add(e2);
		emps.add(e3);
		emps.add(e4);
		emps.add(e5);

		return emps;
	}

	public static void main(String[] args) throws InterruptedException {
		// Create Publisher
		SubmissionPublisher<Employee> publisher = new SubmissionPublisher<>();

		// Register Subscriber
		EmpSubscriber subs = new EmpSubscriber();
		publisher.subscribe(subs);

		List<Employee> emps = getEmps();

		// Publish items
		System.out.println("Publishing Items to Subscriber");
		emps.stream().forEach(i -> publisher.submit(i));

		// logic to wait till processing of all messages are over
		while (emps.size() != subs.getCounter()) {
			Thread.sleep(10);
		}
		
		// close the Publisher
		publisher.close();

		System.out.println("Exiting the app");

	}
}
