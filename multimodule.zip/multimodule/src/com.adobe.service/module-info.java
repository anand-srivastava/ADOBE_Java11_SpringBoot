module com.adobe.service {
    exports com.adobe.empservice; //packages exported
    requires java.logging;
    // exports com.adobe.util;
}