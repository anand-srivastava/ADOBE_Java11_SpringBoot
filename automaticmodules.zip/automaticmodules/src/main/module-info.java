module main {
    requires models;
    requires jackson.core;
    requires jackson.databind;
    requires jackson.annotations;
}