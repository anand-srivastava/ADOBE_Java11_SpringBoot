package client;
import com.example.entity.Person;
import com.fasterxml.jackson.databind.ObjectMapper;
public class Main {
    public static void main(String... args)  throws Exception{
        ObjectMapper mapper  = new ObjectMapper();
        Person p = new Person("Raj",42);
        mapper.writeValue(System.out,p);
    }
}