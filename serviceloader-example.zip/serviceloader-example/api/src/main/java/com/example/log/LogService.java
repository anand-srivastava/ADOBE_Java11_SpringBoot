package com.example.log;

public interface LogService {
	void log(String message);
}
