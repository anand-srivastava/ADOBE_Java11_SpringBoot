module log.client {
    requires log.api;
    uses com.example.log.LogService; 
}