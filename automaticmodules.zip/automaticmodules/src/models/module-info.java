module models {
    exports com.example.entity;
    // requires jackson.annotations;
}