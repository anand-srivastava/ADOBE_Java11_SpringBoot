javac --module-source-path src -p mods -d out -m models,main

java -p out;mods -m main/client.Main

