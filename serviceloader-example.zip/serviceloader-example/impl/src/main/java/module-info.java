import com.example.log.LogService;
import com.example.log.stdout.LogStdOut;

module log.stdout {
    requires log.api;
    exports com.example.log.stdout;
    provides LogService
        with LogStdOut;
}