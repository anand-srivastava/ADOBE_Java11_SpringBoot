package client;

import com.adobe.empservice.EmployeeService;


public class Main {
    public static void main(String[] args) {
        EmployeeService es = new EmployeeService();
        es.addEmployee("smith","smith@adobe.com");
    }
}