mvn package


java -p serviceclient/target/serviceclient-1.0.0.jar;api/target/api-1.0.0.jar;impl/target/impl-1.0.0.jar -m log.client/client.Client

jdeps --module-path serviceclient/target/serviceclient-1.0.0.jar;api/target/api-1.0.0.jar -R --dot-output dots serviceclient/target/serviceclient-1.0.0.jar


JLink: delete all META-INF FOLDERS in jars and

jlink --module-path serviceclient-1.0.0.jar;api-1.0.0.jar;impl-1.0.0.jar --add-modules log.api,log.stdout,log.client --output myappimage --launcher MYAPP=log.client/client.Client