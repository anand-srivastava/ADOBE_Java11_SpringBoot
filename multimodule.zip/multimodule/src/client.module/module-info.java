module client.module {
    requires com.adobe.service;
}