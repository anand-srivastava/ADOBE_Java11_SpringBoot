package com.adobe.util;

public class DbUtil {
    public static void util() {
        System.out.println("I am DB util!!!");
    }
}   